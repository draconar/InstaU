var InstaU = require('./insta_u');

new InstaU({
    port: 3000
});